import { AppointmentStatus, CategoryType, Appointment } from '../types';
import { normalizeDateStr } from './dateUtils';

/**
 * Automatically determines the effective status of an appointment based on its scheduled date and time,
 * while preserving manual overrides (completed / cancelled).
 */
export const getEffectiveStatus = (
  appt: {
    date: string;
    time?: string;
    durationMinutes?: number;
    status: AppointmentStatus;
  },
  referenceDate: Date = new Date()
): AppointmentStatus => {
  // If explicitly marked completed or cancelled, respect user's explicit choice
  if (appt.status === 'completed') return 'completed';
  if (appt.status === 'cancelled') return 'cancelled';

  try {
    const normDate = normalizeDateStr(appt.date);
    const [y, m, d] = normDate.split('-').map(Number);
    if (!y || !m || !d) return appt.status || 'pending';

    const [hours, minutes] = (appt.time || '00:00').split(':').map((v) => Number(v) || 0);
    const scheduledStart = new Date(y, m - 1, d, hours, minutes, 0, 0);
    const nowMs = referenceDate.getTime();
    const startMs = scheduledStart.getTime();

    // If future date/time -> Pendente (Roxo)
    if (nowMs < startMs) {
      return 'pending';
    }

    // If current time has reached or passed the scheduled start time -> Em Andamento (Amarelo)
    return 'in_progress';
  } catch {
    return appt.status || 'pending';
  }
};

/**
 * Returns color classes strictly aligned with requirements:
 * - Cancelado = Vermelho
 * - Concluído = Verde
 * - Em andamento = Amarelo
 * - Pendente = Roxo
 */
export const getRowColorClasses = (status: AppointmentStatus, hasNotes?: boolean) => {
  switch (status) {
    case 'cancelled':
      return {
        bg: 'bg-rose-50/90 dark:bg-rose-950/40 hover:bg-rose-100/80 dark:hover:bg-rose-900/50',
        border: 'border-l-4 border-l-rose-500 border-rose-200/80 dark:border-rose-900/60',
        text: 'text-rose-950 dark:text-rose-200 line-through opacity-85',
        badge: 'bg-rose-100 text-rose-800 dark:bg-rose-900/70 dark:text-rose-200 border border-rose-300 dark:border-rose-800',
        chipBg: 'bg-rose-100/90 text-rose-900 dark:bg-rose-950/80 dark:text-rose-200 border-rose-300 dark:border-rose-800',
        dot: 'bg-rose-500',
        ring: 'ring-rose-400',
        label: 'Cancelado',
        colorName: 'Vermelho'
      };

    case 'completed':
      return {
        bg: 'bg-emerald-50/90 dark:bg-emerald-950/40 hover:bg-emerald-100/80 dark:hover:bg-emerald-900/50',
        border: 'border-l-4 border-l-emerald-500 border-emerald-200/80 dark:border-emerald-900/60',
        text: 'text-emerald-950 dark:text-emerald-200',
        badge: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/70 dark:text-emerald-200 border border-emerald-300 dark:border-emerald-800',
        chipBg: 'bg-emerald-100/90 text-emerald-900 dark:bg-emerald-950/80 dark:text-emerald-200 border-emerald-300 dark:border-emerald-800',
        dot: 'bg-emerald-500',
        ring: 'ring-emerald-400',
        label: 'Concluído',
        colorName: 'Verde'
      };

    case 'in_progress':
      return {
        bg: 'bg-amber-50/90 dark:bg-amber-950/40 hover:bg-amber-100/80 dark:hover:bg-amber-900/50',
        border: 'border-l-4 border-l-amber-500 border-amber-200/80 dark:border-amber-900/60',
        text: 'text-amber-950 dark:text-amber-100 font-medium',
        badge: 'bg-amber-100 text-amber-900 dark:bg-amber-900/70 dark:text-amber-200 border border-amber-300 dark:border-amber-800',
        chipBg: 'bg-amber-100/90 text-amber-950 dark:bg-amber-950/80 dark:text-amber-200 border-amber-300 dark:border-amber-800',
        dot: 'bg-amber-500',
        ring: 'ring-amber-400',
        label: 'Em Andamento',
        colorName: 'Amarelo'
      };

    case 'pending':
    default:
      return {
        bg: 'bg-purple-50/90 dark:bg-purple-950/40 hover:bg-purple-100/80 dark:hover:bg-purple-900/50',
        border: 'border-l-4 border-l-purple-500 border-purple-200/80 dark:border-purple-900/60',
        text: 'text-purple-950 dark:text-purple-100',
        badge: 'bg-purple-100 text-purple-800 dark:bg-purple-900/70 dark:text-purple-200 border border-purple-300 dark:border-purple-800',
        chipBg: 'bg-purple-100/90 text-purple-950 dark:bg-purple-950/80 dark:text-purple-200 border-purple-300 dark:border-purple-800',
        dot: 'bg-purple-500',
        ring: 'ring-purple-400',
        label: 'Pendente',
        colorName: 'Roxo'
      };
  }
};

/**
 * Returns summary of statuses present on a specific date for synchronized date indicators
 */
export const getDayStatusSummary = (appts: Appointment[]) => {
  if (!appts || appts.length === 0) {
    return {
      statuses: [] as AppointmentStatus[],
      primaryStatus: null as AppointmentStatus | null,
      hasNotes: false,
      count: 0
    };
  }

  const effectiveStatuses = appts.map((a) => getEffectiveStatus(a));
  const uniqueStatuses = Array.from(new Set(effectiveStatuses));
  const hasNotes = appts.some((a) => a.notes && a.notes.trim().length > 0);

  // Priority order for day badge styling if multiple: in_progress (Yellow) > pending (Purple) > completed (Green) > cancelled (Red)
  let primaryStatus: AppointmentStatus = 'pending';
  if (uniqueStatuses.includes('in_progress')) {
    primaryStatus = 'in_progress';
  } else if (uniqueStatuses.includes('pending')) {
    primaryStatus = 'pending';
  } else if (uniqueStatuses.includes('completed')) {
    primaryStatus = 'completed';
  } else if (uniqueStatuses.includes('cancelled')) {
    primaryStatus = 'cancelled';
  }

  return {
    statuses: uniqueStatuses,
    primaryStatus,
    hasNotes,
    count: appts.length
  };
};

export const getCategoryBadgeStyle = (category: CategoryType) => {
  switch (category) {
    case 'trabalho':
      return 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 border-blue-200/60';
    case 'pessoal':
      return 'bg-violet-100 text-violet-800 dark:bg-violet-950 dark:text-violet-300 border-violet-200/60';
    case 'reuniao':
      return 'bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-300 border-orange-200/60';
    case 'saude':
      return 'bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300 border-teal-200/60';
    case 'estudos':
      return 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 border-indigo-200/60';
    default:
      return 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300 border-slate-200/60';
  }
};

export const getCategoryLabel = (category: CategoryType) => {
  switch (category) {
    case 'trabalho': return 'Trabalho';
    case 'pessoal': return 'Pessoal';
    case 'reuniao': return 'Reunião';
    case 'saude': return 'Saúde';
    case 'estudos': return 'Estudos';
    default: return 'Outro';
  }
};

export const STATUS_LEGEND = [
  { status: 'cancelled' as AppointmentStatus, label: 'Cancelado', color: 'Vermelho', dotClass: 'bg-rose-500', badgeClass: 'bg-rose-100 text-rose-800 border-rose-300 dark:bg-rose-950 dark:text-rose-300 dark:border-rose-800' },
  { status: 'completed' as AppointmentStatus, label: 'Concluído', color: 'Verde', dotClass: 'bg-emerald-500', badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-950 dark:text-emerald-300 dark:border-emerald-800' },
  { status: 'in_progress' as AppointmentStatus, label: 'Em Andamento', color: 'Amarelo', dotClass: 'bg-amber-500', badgeClass: 'bg-amber-100 text-amber-900 border-amber-300 dark:bg-amber-950 dark:text-amber-200 dark:border-amber-800' },
  { status: 'pending' as AppointmentStatus, label: 'Pendente', color: 'Roxo', dotClass: 'bg-purple-500', badgeClass: 'bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-950 dark:text-purple-300 dark:border-purple-800' }
];
