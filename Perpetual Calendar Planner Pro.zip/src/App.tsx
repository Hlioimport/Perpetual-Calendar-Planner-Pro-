import React, { useState, useEffect, useMemo } from 'react';
import { Navbar } from './components/Navbar';
import { CalendarHeader } from './components/CalendarHeader';
import { PerpetualCalendar } from './components/PerpetualCalendar';
import { AgendaList } from './components/AgendaList';
import { AuthModal } from './components/AuthModal';
import { AppointmentModal } from './components/AppointmentModal';
import { ShareAgendaModal } from './components/ShareAgendaModal';
import { CSVModal } from './components/CSVModal';
import { GoogleCalendarModal } from './components/GoogleCalendarModal';
import { AndroidAppModal } from './components/AndroidAppModal';
import { Toast } from './components/Toast';
import { BrandLogo } from './components/BrandLogo';
import { SplashScreen } from './components/SplashScreen';
import { AppCover } from './components/AppCover';

import { UserProfile, Appointment, AgendaShare, CalendarViewType, FilterOptions, AppointmentStatus } from './types';
import { subscribeToAuthChanges, logoutUser } from './lib/auth';
import {
  subscribeToAppointments,
  addAppointment,
  updateAppointment,
  deleteAppointment,
  subscribeToSharedAgendas,
  getLocalAppointments,
  saveLocalAppointments,
  syncLocalToCloud,
  isSeedInitialized,
  markSeedInitialized
} from './lib/db';
import { formatDateToISO, normalizeDateStr, parseISODate } from './lib/dateUtils';
import { getEffectiveStatus } from './lib/colorUtils';
import { Cloud, Lock, Calendar as CalendarIcon, Sparkles, WifiOff, RefreshCw, UserCheck } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [isGuestMode, setIsGuestMode] = useState<boolean>(false);
  const [isOnline, setIsOnline] = useState<boolean>(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [selectedDateStr, setSelectedDateStr] = useState<string>(formatDateToISO(new Date()));
  const [agendaScope, setAgendaScope] = useState<'day' | 'month' | 'all'>('day');
  
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [sharedAgendas, setSharedAgendas] = useState<AgendaShare[]>([]);
  const [activeAgendaUid, setActiveAgendaUid] = useState<string | null>(null);

  const [calendarView, setCalendarView] = useState<CalendarViewType>('month');
  
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({
    searchTerm: '',
    category: 'all',
    status: 'all',
    onlyWithNotes: false
  });

  // Modal States
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isCSVModalOpen, setIsCSVModalOpen] = useState(false);
  const [isGoogleCalendarModalOpen, setIsGoogleCalendarModalOpen] = useState(false);
  const [isAndroidModalOpen, setIsAndroidModalOpen] = useState(false);
  const [isApptModalOpen, setIsApptModalOpen] = useState(false);
  const [editingAppt, setEditingAppt] = useState<Appointment | null>(null);

  // Opening Logo Splash Screen state
  const [showSplash, setShowSplash] = useState<boolean>(() => {
    if (typeof window !== 'undefined' && sessionStorage.getItem('splash_viewed')) {
      return false;
    }
    return true;
  });

  const handleSplashFinish = () => {
    setShowSplash(false);
    if (typeof window !== 'undefined') {
      sessionStorage.setItem('splash_viewed', 'true');
    }
  };

  // PWA Install Prompt State
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  // Toast State
  const [toast, setToast] = useState<{ message: string | null; type?: 'success' | 'error' | 'info' }>({ message: null });

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
  };

  // Seed sample local data ONLY once on first initial visit in guest mode
  useEffect(() => {
    if (!isSeedInitialized() && !currentUser) {
      markSeedInitialized();
      const localData = getLocalAppointments();
      if (localData.length === 0) {
        const today = new Date();
        const todayIso = formatDateToISO(today);
        
        const seed: Appointment[] = [
          {
            id: 'local_sample_1',
            userId: '',
            userEmail: '',
            title: 'Reunião de Alinhamento Semanal',
            date: todayIso,
            time: '09:00',
            durationMinutes: 60,
            category: 'reuniao',
            status: 'pending',
            notes: 'Apresentar metas do mês e revisar compromissos agendados.',
            createdAt: Date.now(),
            updatedAt: Date.now()
          },
          {
            id: 'local_sample_2',
            userId: '',
            userEmail: '',
            title: 'Acompanhamento do Projeto Principal',
            date: todayIso,
            time: '14:30',
            category: 'trabalho',
            status: 'in_progress',
            notes: 'Sincronização da agenda individual segura na nuvem.',
            createdAt: Date.now(),
            updatedAt: Date.now()
          }
        ];
        saveLocalAppointments(seed);
        if (isGuestMode) {
          setAppointments(seed);
        }
      }
    } else if (!currentUser && isGuestMode) {
      setAppointments(getLocalAppointments());
    }
  }, [currentUser, isGuestMode]);

  // Online/Offline status listeners & auto-sync
  useEffect(() => {
    const handleOnline = async () => {
      setIsOnline(true);
      showToast('Conexão restabelecida! Sincronizando dados com a nuvem...', 'info');
      if (currentUser) {
        const synced = await syncLocalToCloud(currentUser.uid, currentUser.email);
        if (synced > 0) {
          showToast(`Sincronizados ${synced} compromisso(s) criados offline!`, 'success');
        }
      }
    };

    const handleOffline = () => {
      setIsOnline(false);
      showToast('Você está offline. Compromissos serão salvos localmente.', 'info');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [currentUser]);

  // Auto-sync local user-created offline items
  useEffect(() => {
    if (currentUser && isOnline) {
      syncLocalToCloud(currentUser.uid, currentUser.email).then((synced) => {
        if (synced > 0) {
          showToast(`Sincronizados ${synced} compromisso(s) offline com sua conta!`, 'success');
        }
      });
    }
  }, [currentUser, isOnline]);

  // Auth Subscription
  useEffect(() => {
    const unsubAuth = subscribeToAuthChanges((user) => {
      setCurrentUser(user);
      if (user) {
        setIsGuestMode(false);
      } else {
        setActiveAgendaUid(null);
      }
    });
    return () => unsubAuth();
  }, []);

  // Shared Agendas Listener
  useEffect(() => {
    if (currentUser) {
      const unsubShares = subscribeToSharedAgendas(currentUser.email, currentUser.uid, (shares) => {
        setSharedAgendas(shares);
      });
      return () => unsubShares();
    } else {
      setSharedAgendas([]);
    }
  }, [currentUser]);

  // Appointments Listener
  useEffect(() => {
    if (!currentUser && isGuestMode) {
      setAppointments(getLocalAppointments());
      return;
    }

    if (!currentUser) return;

    const unsubAppts = subscribeToAppointments(
      currentUser.uid,
      currentUser.email,
      activeAgendaUid,
      (data) => {
        setAppointments(data);
      },
      (err) => {
        showToast('Erro ao carregar dados da nuvem. Exibindo dados locais.', 'error');
      }
    );
    return () => unsubAppts();
  }, [currentUser, activeAgendaUid, isGuestMode]);

  const handlePrevMonth = () => {
    setCurrentDate((prev) => new Date(prev.getFullYear(), prev.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate((prev) => new Date(prev.getFullYear(), prev.getMonth() + 1, 1));
  };

  const handleToday = () => {
    const today = new Date();
    setCurrentDate(today);
    setSelectedDateStr(formatDateToISO(today));
  };

  const handleYearChange = (year: number) => {
    setCurrentDate((prev) => new Date(year, prev.getMonth(), 1));
  };

  const handleMonthChange = (month: number) => {
    setCurrentDate((prev) => new Date(prev.getFullYear(), month, 1));
  };

  const handleOpenNewAppointment = (dateStr?: string) => {
    const normDate = dateStr ? normalizeDateStr(dateStr) : selectedDateStr;
    setSelectedDateStr(normDate);
    setEditingAppt(null);
    setIsApptModalOpen(true);
  };

  const handleEditAppointment = (appt: Appointment) => {
    setEditingAppt(appt);
    setIsApptModalOpen(true);
  };

  const handleSelectDate = (dateStr: string) => {
    const norm = normalizeDateStr(dateStr);
    setSelectedDateStr(norm);
    const parsed = parseISODate(norm);
    if (parsed.getMonth() !== currentDate.getMonth() || parsed.getFullYear() !== currentDate.getFullYear()) {
      setCurrentDate(parsed);
    }
  };

  const handleSaveAppointment = async (
    apptData: Omit<Appointment, 'id' | 'userId' | 'userEmail' | 'createdAt' | 'updatedAt'>
  ) => {
    try {
      const normalizedDate = normalizeDateStr(apptData.date);
      const sanitizedApptData = {
        ...apptData,
        date: normalizedDate
      };

      if (editingAppt) {
        await updateAppointment(editingAppt.id, currentUser?.uid || '', sanitizedApptData);
        setAppointments((prev) =>
          prev.map((a) =>
            a.id === editingAppt.id ? { ...a, ...sanitizedApptData, updatedAt: Date.now() } : a
          )
        );
        showToast('Compromisso atualizado com sucesso!');
      } else {
        const newId = await addAppointment(
          currentUser?.uid || '',
          currentUser?.email || 'convidado@local',
          sanitizedApptData
        );
        const newAppt: Appointment = {
          id: newId,
          ...sanitizedApptData,
          userId: currentUser?.uid || '',
          userEmail: currentUser?.email || '',
          createdAt: Date.now(),
          updatedAt: Date.now(),
          status: sanitizedApptData.status || 'pending',
          category: sanitizedApptData.category || 'trabalho'
        };
        setAppointments((prev) => [...prev.filter((a) => a.id !== newId), newAppt]);
        showToast('Novo compromisso salvo com sucesso!');
      }

      // Automatically select the date of the saved appointment and sync calendar view
      setSelectedDateStr(normalizedDate);
      const parsedDate = parseISODate(normalizedDate);
      if (parsedDate.getMonth() !== currentDate.getMonth() || parsedDate.getFullYear() !== currentDate.getFullYear()) {
        setCurrentDate(parsedDate);
      }
    } catch (err: any) {
      console.error(err);
      showToast('Erro ao salvar compromisso.', 'error');
    }
  };

  const handleDeleteAppointment = async (id: string) => {
    // Optimistic removal from state immediately
    setAppointments((prev) => prev.filter((a) => a.id !== id));
    try {
      await deleteAppointment(id, currentUser?.uid || '');
      showToast('Compromisso excluído.');
    } catch (err) {
      console.error(err);
      showToast('Erro ao excluir compromisso.', 'error');
      if (isGuestMode || !currentUser) {
        setAppointments(getLocalAppointments());
      }
    }
  };

  const handleToggleStatus = async (id: string, newStatus: AppointmentStatus) => {
    // Optimistic toggle in state immediately
    setAppointments((prev) =>
      prev.map((a) => (a.id === id ? { ...a, status: newStatus, updatedAt: Date.now() } : a))
    );

    try {
      await updateAppointment(id, currentUser?.uid || '', { status: newStatus });
      const statusLabels: Record<AppointmentStatus, string> = {
        cancelled: 'Cancelado (Vermelho)',
        completed: 'Concluído (Verde)',
        in_progress: 'Em Andamento (Amarelo)',
        pending: 'Pendente (Roxo)'
      };
      showToast(`Status: ${statusLabels[newStatus] || newStatus}`);
    } catch (err) {
      console.error(err);
      showToast('Erro ao atualizar status.', 'error');
    }
  };

  const handleImportCSVAppointments = async (
    newAppts: Omit<Appointment, 'id' | 'userId' | 'userEmail' | 'createdAt' | 'updatedAt'>[]
  ) => {
    for (const appt of newAppts) {
      await addAppointment(currentUser?.uid || '', currentUser?.email || 'convidado@local', appt);
    }
    if (isGuestMode) {
      setAppointments(getLocalAppointments());
    }
  };

  const handleLogout = async () => {
    await logoutUser();
    setIsGuestMode(false);
    showToast('Você saiu da sua conta.');
  };

  const filteredAppointments = useMemo(() => {
    const normSelected = normalizeDateStr(selectedDateStr);
    const currYear = currentDate.getFullYear();
    const currMonth = currentDate.getMonth();

    return appointments.filter((appt) => {
      const normApptDate = normalizeDateStr(appt.date);
      
      const matchesSearch =
        filterOptions.searchTerm === '' ||
        appt.title.toLowerCase().includes(filterOptions.searchTerm.toLowerCase()) ||
        (appt.notes && appt.notes.toLowerCase().includes(filterOptions.searchTerm.toLowerCase()));

      const matchesCategory =
        filterOptions.category === 'all' || appt.category === filterOptions.category;

      const effectiveStatus = getEffectiveStatus(appt);
      const matchesStatus =
        filterOptions.status === 'all' ||
        appt.status === filterOptions.status ||
        effectiveStatus === filterOptions.status;

      const matchesNotes =
        !filterOptions.onlyWithNotes || Boolean(appt.notes && appt.notes.trim().length > 0);

      if (!matchesSearch || !matchesCategory || !matchesStatus || !matchesNotes) {
        return false;
      }

      // If user is searching or in agenda mode
      if (filterOptions.searchTerm.trim() !== '' || calendarView === 'agenda') {
        if (agendaScope === 'day') {
          return normApptDate === normSelected;
        }
        if (agendaScope === 'month') {
          const apptD = parseISODate(normApptDate);
          return apptD.getFullYear() === currYear && apptD.getMonth() === currMonth;
        }
        return true;
      }

      // In month view
      if (agendaScope === 'month') {
        const apptD = parseISODate(normApptDate);
        return apptD.getFullYear() === currYear && apptD.getMonth() === currMonth;
      }
      if (agendaScope === 'all') {
        return true;
      }

      return normApptDate === normSelected;
    });
  }, [appointments, selectedDateStr, currentDate, calendarView, filterOptions, agendaScope]);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans">
      
      {/* NAVBAR CORRIGIDA SEM ERROS DE FECHAMENTO */}
      <Navbar
        currentUser={currentUser || (isGuestMode ? ({ uid: 'guest', email: 'convidado@local', displayName: 'Convidado' } as any) : null)}
        isOnline={isOnline}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        onOpenShareModal={() => setIsShareModalOpen(true)}
        onOpenCSVModal={() => setIsCSVModalOpen(true)}
        onOpenGoogleCalendarModal={() => setIsGoogleCalendarModalOpen(true)}
        onOpenAndroidModal={() => setIsAndroidModalOpen(true)}
        onLogout={handleLogout}
        sharedAgendas={sharedAgendas}
        activeAgendaUid={activeAgendaUid}
        onSelectAgenda={setActiveAgendaUid}
        onReplaySplash={() => setShowSplash(true)}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        
        {!isOnline && (
          <div className="p-4 bg-amber-500/10 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 border border-amber-300 dark:border-amber-800/60 rounded-2xl flex items-center justify-between gap-3 text-xs shadow-sm">
            <div className="flex items-center gap-3">
              <WifiOff className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              <span>Modo Offline Ativo. As alterações serão salvas localmente.</span>
            </div>
          </div>
        )}

        {!currentUser && !isGuestMode && (
          <div className="p-6 bg-gradient-to-r from-indigo-900 via-slate-950 to-indigo-900 text-white rounded-2xl shadow-xl border border-indigo-800/40 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <Lock className="w-6 h-6 text-indigo-300" />
              <div>
                <h2 className="text-base font-bold tracking-tight">Acesse sua Agenda Individual Protegida</h2>
                <p className="text-xs text-indigo-200/80 mt-1 max-w-xl">
                  Faça login para salvar na nuvem ou use o <strong>Modo Convidado</strong> para visualizar a interface imediatamente.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3 w-full md:w-auto justify-end">
              <button
                onClick={() => setIsGuestMode(true)}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white text-xs font-semibold rounded-xl transition flex items-center gap-2"
              >
                <UserCheck className="w-4 h-4 text-emerald-400" />
                Entrar como Convidado
              </button>
              <button
                onClick={() => setIsAuthModalOpen(true)}
                className="px-5 py-2.5 bg-indigo-500 hover:bg-indigo-600 text-white text-xs font-bold rounded-xl transition"
              >
                Entrar / Conta Google
              </button>
            </div>
          </div>
        )}

        {(currentUser || isGuestMode) ? (
          <>
            {/* App Cover Banner with Modern Logo & Synchronized Metrics */}
            <AppCover
              appointments={appointments}
              currentDate={currentDate}
              onOpenNewAppointment={() => handleOpenNewAppointment(selectedDateStr)}
              onGoToday={handleToday}
              onOpenAndroidModal={() => setIsAndroidModalOpen(true)}
              userEmail={currentUser?.email || (isGuestMode ? 'Modo Convidado' : null)}
            />

            <CalendarHeader
              currentDate={currentDate}
              onPrevMonth={handlePrevMonth}
              onNextMonth={handleNextMonth}
              onToday={handleToday}
              onYearChange={handleYearChange}
              onMonthChange={handleMonthChange}
              view={calendarView}
              onViewChange={setCalendarView}
              onOpenNewAppointment={() => handleOpenNewAppointment(selectedDateStr)}
              filterOptions={filterOptions}
              onFilterChange={setFilterOptions}
              totalAppointmentsCount={appointments.length}
            />

            {calendarView === 'month' ? (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                <div className="lg:col-span-7 xl:col-span-8">
                  <PerpetualCalendar
                    currentDate={currentDate}
                    selectedDateStr={selectedDateStr}
                    onSelectDate={handleSelectDate}
                    appointments={appointments}
                    onOpenNewForDate={handleOpenNewAppointment}
                  />
                </div>
                <div className="lg:col-span-5 xl:col-span-4">
                  <AgendaList
                    selectedDateStr={selectedDateStr}
                    appointments={filteredAppointments}
                    allAppointments={appointments}
                    allAppointmentsCount={appointments.length}
                    onEditAppointment={handleEditAppointment}
                    onDeleteAppointment={handleDeleteAppointment}
                    onToggleStatus={handleToggleStatus}
                    onOpenNewAppointment={handleOpenNewAppointment}
                    onSelectDate={handleSelectDate}
                    viewScope={agendaScope}
                    onViewScopeChange={setAgendaScope}
                  />
                </div>
              </div>
            ) : (
              <div className="max-w-4xl mx-auto">
                <AgendaList
                  selectedDateStr={selectedDateStr}
                  appointments={filteredAppointments}
                  allAppointments={appointments}
                  allAppointmentsCount={appointments.length}
                  onEditAppointment={handleEditAppointment}
                  onDeleteAppointment={handleDeleteAppointment}
                  onToggleStatus={handleToggleStatus}
                  onOpenNewAppointment={handleOpenNewAppointment}
                  onSelectDate={handleSelectDate}
                  filterTitle="Todas as Anotações da Agenda"
                  viewScope={agendaScope}
                  onViewScopeChange={setAgendaScope}
                />
              </div>
            )}
          </>
        ) : (
          <div className="text-center py-20 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800">
            <CalendarIcon className="w-16 h-16 mx-auto text-indigo-500/80 mb-4 animate-pulse" />
            <h3 className="text-lg font-bold">Agenda Inicializar</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
              Escolha uma das opções no banner acima para liberar o seu calendário.
            </p>
          </div>
        )}

      </main>

      <footer className="bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 py-6 text-center text-xs text-slate-500 dark:text-slate-400">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <BrandLogo size="sm" showText={true} />
          <p>© {new Date().getFullYear()} Perpetual Calendar Planner — Protegido e Sincronizado na Nuvem</p>
        </div>
      </footer>

      {/* Modais */}
      <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} onSuccess={(msg) => showToast(msg, 'success')} />
      <AppointmentModal isOpen={isApptModalOpen} onClose={() => setIsApptModalOpen(false)} onSave={handleSaveAppointment} onDelete={handleDeleteAppointment} initialDateStr={selectedDateStr} editingAppointment={editingAppt} />
      <ShareAgendaModal isOpen={isShareModalOpen} onClose={() => setIsShareModalOpen(false)} currentUser={currentUser} sharedAgendas={sharedAgendas} onSuccess={(msg) => showToast(msg, 'success')} />
      <CSVModal isOpen={isCSVModalOpen} onClose={() => setIsCSVModalOpen(false)} onImportAppointments={handleImportCSVAppointments} currentAppointments={appointments} onSuccess={(msg) => showToast(msg, 'success')} />
      <GoogleCalendarModal isOpen={isGoogleCalendarModalOpen} onClose={() => setIsGoogleCalendarModalOpen(false)} appointments={appointments} onImportAppointments={async (importedAppts) => {
          for (const appt of importedAppts) {
            await addAppointment(currentUser?.uid || '', currentUser?.email || 'convidado@local', {
                title: appt.title || 'Compromisso',
                date: appt.date || formatDateToISO(new Date()),
                time: appt.time || '09:00',
                category: appt.category || 'outro',
                status: appt.status || 'pending',
                notes: appt.notes || ''
            });
          }
          showToast(`${importedAppts.length} evento(s) importados!`, 'success');
          if (isGuestMode) setAppointments(getLocalAppointments());
      }} />
      <AndroidAppModal isOpen={isAndroidModalOpen} onClose={() => setIsAndroidModalOpen(false)} deferredPrompt={deferredPrompt} appUrl={typeof window !== 'undefined' ? window.location.origin : ''} onInstallPwa={() => {
          if (deferredPrompt) {
            deferredPrompt.prompt();
            deferredPrompt.userChoice.then((choiceResult: any) => {
              if (choiceResult.outcome === 'accepted') showToast('Instalação iniciada!', 'success');
              setDeferredPrompt(null);
            });
          }
      }} />
      <Toast message={toast.message} type={toast.type} onClose={() => setToast({ message: null })} />

      {/* Opening Logo Splash Screen */}
      {showSplash && (
        <SplashScreen onFinish={handleSplashFinish} />
      )}

    </div>
  );
}