import React from 'react';

export interface BrandLogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  variant?: 'horizontal' | 'vertical' | 'hero' | 'badge';
  showText?: boolean;
  showStatusDots?: boolean;
  subtitle?: string;
  className?: string;
  glow?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  size = 'md',
  variant = 'horizontal',
  showText = true,
  showStatusDots = true,
  subtitle,
  className = '',
  glow = true
}) => {
  const iconDimensions = {
    xs: 'w-7 h-7 rounded-lg',
    sm: 'w-8 h-8 rounded-xl',
    md: 'w-10 h-10 rounded-2xl',
    lg: 'w-12 h-12 rounded-2xl',
    xl: 'w-16 h-16 rounded-3xl',
    '2xl': 'w-24 h-24 rounded-3xl'
  };

  const textSizes = {
    xs: 'text-xs',
    sm: 'text-sm sm:text-base',
    md: 'text-base sm:text-lg',
    lg: 'text-xl sm:text-2xl',
    xl: 'text-2xl sm:text-3xl',
    '2xl': 'text-3xl sm:text-4xl'
  };

  const isVertical = variant === 'vertical' || variant === 'hero';

  return (
    <div
      className={`flex select-none transition-all duration-300 ${
        isVertical ? 'flex-col items-center text-center gap-3' : 'items-center gap-3'
      } ${className}`}
    >
      {/* Modern Gradient Icon Badge with Perpetual Calendar Geometry & Status Sinks */}
      <div
        className={`relative ${iconDimensions[size]} bg-gradient-to-br from-indigo-600 via-indigo-700 to-slate-900 text-white flex items-center justify-center shadow-lg shadow-indigo-500/25 ring-1 ring-white/20 dark:ring-indigo-400/20 shrink-0 group overflow-hidden ${
          glow ? 'hover:shadow-indigo-500/40 hover:scale-105' : ''
        }`}
      >
        {/* Ambient glow accent inside */}
        <div className="absolute -top-3 -right-3 w-10 h-10 bg-indigo-400/30 rounded-full blur-md group-hover:scale-125 transition duration-500" />
        <div className="absolute -bottom-3 -left-3 w-10 h-10 bg-purple-500/25 rounded-full blur-md" />

        {/* Sophisticated Perpetual Calendar Geometric Vector Icon */}
        <svg
          viewBox="0 0 32 32"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-3/5 h-3/5 text-white transform group-hover:scale-105 transition-transform duration-300 relative z-10"
        >
          {/* Calendar top ring anchors */}
          <rect x="8" y="3" width="2.5" height="5" rx="1.25" fill="#A5B4FC" />
          <rect x="21.5" y="3" width="2.5" height="5" rx="1.25" fill="#A5B4FC" />

          {/* Calendar Frame */}
          <rect
            x="4"
            y="5.5"
            width="24"
            height="21.5"
            rx="5"
            className="fill-indigo-950/40 stroke-white/90"
            strokeWidth="2"
          />

          {/* Header Divider line */}
          <path d="M4 12H28" stroke="white" strokeWidth="1.5" strokeOpacity="0.4" />

          {/* Synchronized 4 Status Color Grid Nodes (Purple, Amber, Green, Rose) */}
          {/* Top row */}
          <circle cx="9.5" cy="16.5" r="1.6" className="fill-purple-400" />
          <circle cx="16" cy="16.5" r="1.6" className="fill-amber-400" />
          <circle cx="22.5" cy="16.5" r="1.6" className="fill-emerald-400" />

          {/* Bottom row perpetual pulse node */}
          <circle cx="9.5" cy="22" r="1.6" className="fill-rose-400" />
          <path
            d="M14.5 22H23.5"
            stroke="#C7D2FE"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeDasharray="2 2"
          />
        </svg>
      </div>

      {/* Brand Typography */}
      {showText && (
        <div className={`flex flex-col ${isVertical ? 'items-center' : 'items-start'}`}>
          <div className="flex items-center gap-1.5 leading-none">
            <h1 className={`font-black tracking-tight text-slate-900 dark:text-white ${textSizes[size]}`}>
              Perpetual Calendar{' '}
              <span className="bg-gradient-to-r from-indigo-600 via-indigo-500 to-purple-600 dark:from-indigo-400 dark:via-indigo-300 dark:to-purple-300 bg-clip-text text-transparent">
                Planner
              </span>
            </h1>
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 dark:bg-indigo-400 shrink-0 animate-pulse" />
          </div>

          {/* Optional Synchronized Status Legend Dots in Hero/Vertical View */}
          {showStatusDots && (variant === 'hero' || size === 'xl' || size === '2xl') && (
            <div className="flex items-center gap-2 mt-2 px-2.5 py-1 bg-slate-100 dark:bg-slate-800/80 rounded-full border border-slate-200/80 dark:border-slate-700 text-[11px] font-medium text-slate-600 dark:text-slate-300">
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-purple-500" />
                <span>Pendente</span>
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-amber-500" />
                <span>Em Andamento</span>
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                <span>Concluído</span>
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-rose-500" />
                <span>Cancelado</span>
              </span>
            </div>
          )}

          {subtitle && (
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 leading-tight truncate">
              {subtitle}
            </p>
          )}
        </div>
      )}
    </div>
  );
};
