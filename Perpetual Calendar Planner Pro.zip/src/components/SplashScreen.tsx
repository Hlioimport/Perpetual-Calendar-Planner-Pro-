import React, { useState, useEffect } from 'react';
import { BrandLogo } from './BrandLogo';
import { Sparkles, ArrowRight, Shield, Cloud, Calendar } from 'lucide-react';

interface SplashScreenProps {
  onFinish?: () => void;
  autoCloseDelay?: number;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  onFinish,
  autoCloseDelay = 1800
}) => {
  const [progress, setProgress] = useState(15);
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    // Smooth progress bar animation
    const timer1 = setTimeout(() => setProgress(45), 250);
    const timer2 = setTimeout(() => setProgress(80), 700);
    const timer3 = setTimeout(() => setProgress(100), 1200);

    const closeTimer = setTimeout(() => {
      setFadeOut(true);
      setTimeout(() => {
        if (onFinish) onFinish();
      }, 400);
    }, autoCloseDelay);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(closeTimer);
    };
  }, [autoCloseDelay, onFinish]);

  const handleSkip = () => {
    setFadeOut(true);
    setTimeout(() => {
      if (onFinish) onFinish();
    }, 200);
  };

  return (
    <div
      className={`fixed inset-0 z-[999] flex flex-col items-center justify-between p-6 sm:p-10 bg-slate-950 text-white transition-opacity duration-500 overflow-hidden ${
        fadeOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Background Ambient Glow & Grid Accent */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-900/40 via-slate-950 to-slate-950 pointer-events-none" />
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-indigo-600/15 rounded-full blur-3xl pointer-events-none animate-pulse" />
      <div className="absolute bottom-10 right-10 w-72 h-72 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Header details */}
      <div className="w-full max-w-lg flex items-center justify-between z-10">
        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900/80 border border-slate-800 text-xs font-semibold text-indigo-300">
          <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
          <span>Sistema Perpétuo 2025–2055+</span>
        </div>
        <button
          onClick={handleSkip}
          className="text-xs text-slate-400 hover:text-white px-3 py-1 rounded-full hover:bg-slate-900 transition flex items-center gap-1"
        >
          <span>Pular Abertura</span>
          <ArrowRight className="w-3 h-3" />
        </button>
      </div>

      {/* Central Hero Logo with Opening Animation */}
      <div className="relative z-10 flex flex-col items-center text-center space-y-6 max-w-md my-auto">
        
        {/* Animated Glow Ring Behind Logo */}
        <div className="relative">
          <div className="absolute -inset-4 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-3xl blur-lg opacity-40 animate-pulse" />
          
          <BrandLogo
            size="2xl"
            variant="hero"
            showStatusDots={true}
            className="transform hover:scale-105 transition duration-500"
          />
        </div>

        {/* Brand Narrative */}
        <div className="space-y-2">
          <p className="text-sm font-medium text-slate-300">
            Calendário Perpétuo, Anotações & Gestão Temporal Sincronizada
          </p>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Organização contínua de compromissos com status em tempo real e proteção individual na nuvem.
          </p>
        </div>

        {/* Progress Bar */}
        <div className="w-64 sm:w-72 space-y-2 pt-2">
          <div className="w-full h-1.5 bg-slate-800/80 rounded-full overflow-hidden border border-slate-700/60 p-0.2">
            <div
              className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-indigo-400 rounded-full transition-all duration-500 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-medium px-1">
            <span className="flex items-center gap-1">
              <Cloud className="w-3 h-3 text-indigo-400" />
              <span>Inicializando agenda...</span>
            </span>
            <span>{progress}%</span>
          </div>
        </div>

      </div>

      {/* Footer Security Badges */}
      <div className="w-full max-w-lg flex items-center justify-center gap-4 text-[11px] text-slate-400 z-10 pt-4 border-t border-slate-900/60">
        <span className="flex items-center gap-1.5">
          <Shield className="w-3.5 h-3.5 text-emerald-400" />
          <span>Acesso Privado Protegido</span>
        </span>
        <span>•</span>
        <span className="flex items-center gap-1.5">
          <Calendar className="w-3.5 h-3.5 text-indigo-400" />
          <span>Sem Limite de Anos</span>
        </span>
      </div>

    </div>
  );
};
