import React, { useState } from 'react';
import { BrandLogo } from './BrandLogo';
import { Appointment } from '../types';
import { getEffectiveStatus } from '../lib/colorUtils';
import {
  Calendar as CalendarIcon,
  Sparkles,
  Plus,
  ChevronDown,
  ChevronUp,
  Shield,
  Smartphone
} from 'lucide-react';
import { formatFullDatePT } from '../lib/dateUtils';

interface AppCoverProps {
  appointments: Appointment[];
  currentDate: Date;
  onOpenNewAppointment: () => void;
  onGoToday: () => void;
  onOpenAndroidModal?: () => void;
  userEmail?: string | null;
}

export const AppCover: React.FC<AppCoverProps> = ({
  appointments,
  currentDate,
  onOpenNewAppointment,
  onGoToday,
  onOpenAndroidModal,
  userEmail
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  // Compute status metrics for synchronized status summary in the cover
  const metrics = React.useMemo(() => {
    let pending = 0;
    let inProgress = 0;
    let completed = 0;
    let cancelled = 0;

    appointments.forEach((a) => {
      const st = getEffectiveStatus(a);
      if (st === 'pending') pending++;
      else if (st === 'in_progress') inProgress++;
      else if (st === 'completed') completed++;
      else if (st === 'cancelled') cancelled++;
    });

    return {
      total: appointments.length,
      pending,
      inProgress,
      completed,
      cancelled
    };
  }, [appointments]);

  const todayFormatted = formatFullDatePT(new Date());

  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl border border-indigo-900/40 shadow-xl transition-all duration-300">
      
      {/* Decorative Background Lighting & Vectors */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-10 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -top-10 left-1/3 w-40 h-40 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

      {/* Main Cover Header */}
      <div className="relative z-10 p-5 sm:p-7">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          
          {/* Left: Brand Identity & Subtitle */}
          <div className="space-y-3 max-w-xl">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-200 text-xs font-semibold backdrop-blur-xs">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Capa Oficial • Perpetual Calendar Planner</span>
              </span>
              
              {userEmail && (
                <span className="hidden sm:inline-flex items-center gap-1 text-xs text-slate-300 bg-slate-800/80 px-2.5 py-0.5 rounded-full border border-slate-700">
                  <Shield className="w-3 h-3 text-emerald-400" />
                  <span className="truncate max-w-[160px]">{userEmail}</span>
                </span>
              )}
            </div>

            <BrandLogo
              size="lg"
              variant="horizontal"
              showStatusDots={false}
              className="text-white"
            />

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
              Seu planejador perpétuo com sincronização de status em tempo real (Roxo, Amarelo, Verde e Vermelho), gestão de anotações e navegação temporal contínua.
            </p>
          </div>

          {/* Right: Quick Action Controls & Live Date Badge */}
          <div className="flex flex-col sm:flex-row lg:flex-col items-start sm:items-center lg:items-end justify-between gap-4">
            
            {/* Live date pill */}
            <div className="bg-slate-800/70 border border-indigo-800/60 rounded-2xl px-4 py-2 text-left sm:text-right backdrop-blur-xs">
              <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-300 block">
                Hoje é:
              </span>
              <span className="text-xs sm:text-sm font-bold text-white capitalize">
                {todayFormatted}
              </span>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={onOpenNewAppointment}
                className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-lg shadow-indigo-600/30 flex items-center gap-2 transition transform hover:-translate-y-0.5"
              >
                <Plus className="w-4 h-4" />
                <span>Novo Compromisso</span>
              </button>

              <button
                onClick={onGoToday}
                className="px-3.5 py-2.5 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-semibold border border-white/10 flex items-center gap-1.5 transition"
              >
                <CalendarIcon className="w-3.5 h-3.5 text-indigo-300" />
                <span>Hoje</span>
              </button>

              {onOpenAndroidModal && (
                <button
                  onClick={onOpenAndroidModal}
                  className="px-3.5 py-2.5 bg-emerald-950/80 hover:bg-emerald-900/90 text-emerald-300 rounded-xl text-xs font-semibold border border-emerald-700/60 flex items-center gap-1.5 transition"
                  title="Instalar App Android"
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">App Android</span>
                </button>
              )}

              {/* Collapse/Expand Toggle */}
              <button
                onClick={() => setIsCollapsed(!isCollapsed)}
                className="p-2.5 text-slate-400 hover:text-white rounded-xl hover:bg-white/10 transition"
                title={isCollapsed ? 'Expandir Capa' : 'Recolher Capa'}
              >
                {isCollapsed ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
              </button>
            </div>

          </div>

        </div>

        {/* Collapsible Status Metrics Strip Synchronized with Calendar */}
        {!isCollapsed && (
          <div className="mt-6 pt-5 border-t border-indigo-900/50 grid grid-cols-2 sm:grid-cols-4 gap-3">
            
            {/* Pending (Roxo) */}
            <div className="bg-purple-950/40 border border-purple-800/50 rounded-2xl p-3 flex items-center gap-3 backdrop-blur-xs">
              <span className="w-3 h-3 rounded-full bg-purple-500 shadow-sm shadow-purple-500/50 shrink-0" />
              <div>
                <span className="text-[10px] uppercase font-bold text-purple-300 block">Pendente (Roxo)</span>
                <span className="text-base font-black text-white">{metrics.pending}</span>
              </div>
            </div>

            {/* In Progress (Amarelo) */}
            <div className="bg-amber-950/40 border border-amber-800/50 rounded-2xl p-3 flex items-center gap-3 backdrop-blur-xs">
              <span className="w-3 h-3 rounded-full bg-amber-500 shadow-sm shadow-amber-500/50 shrink-0" />
              <div>
                <span className="text-[10px] uppercase font-bold text-amber-300 block">Em Andamento (Amarelo)</span>
                <span className="text-base font-black text-white">{metrics.inProgress}</span>
              </div>
            </div>

            {/* Completed (Verde) */}
            <div className="bg-emerald-950/40 border border-emerald-800/50 rounded-2xl p-3 flex items-center gap-3 backdrop-blur-xs">
              <span className="w-3 h-3 rounded-full bg-emerald-500 shadow-sm shadow-emerald-500/50 shrink-0" />
              <div>
                <span className="text-[10px] uppercase font-bold text-emerald-300 block">Concluído (Verde)</span>
                <span className="text-base font-black text-white">{metrics.completed}</span>
              </div>
            </div>

            {/* Cancelled (Vermelho) */}
            <div className="bg-rose-950/40 border border-rose-800/50 rounded-2xl p-3 flex items-center gap-3 backdrop-blur-xs">
              <span className="w-3 h-3 rounded-full bg-rose-500 shadow-sm shadow-rose-500/50 shrink-0" />
              <div>
                <span className="text-[10px] uppercase font-bold text-rose-300 block">Cancelado (Vermelho)</span>
                <span className="text-base font-black text-white">{metrics.cancelled}</span>
              </div>
            </div>

          </div>
        )}

      </div>

    </div>
  );
};
