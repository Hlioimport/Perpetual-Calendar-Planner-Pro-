import React from 'react';
import { Appointment, AppointmentStatus } from '../types';
import {
  getRowColorClasses,
  getCategoryBadgeStyle,
  getCategoryLabel,
  getEffectiveStatus,
  getDayStatusSummary,
  STATUS_LEGEND
} from '../lib/colorUtils';
import { formatFullDatePT, normalizeDateStr, formatShortDatePT } from '../lib/dateUtils';
import { generateGoogleCalendarUrl } from '../lib/googleCalendar';
import {
  Clock,
  FileText,
  CheckCircle2,
  Circle,
  Pencil,
  Trash2,
  Calendar as CalendarIcon,
  Plus,
  ExternalLink,
  ChevronRight,
  Sparkles,
  CalendarDays,
  XCircle,
  AlertCircle
} from 'lucide-react';

interface AgendaListProps {
  selectedDateStr: string;
  appointments: Appointment[];
  allAppointments?: Appointment[];
  allAppointmentsCount: number;
  onEditAppointment: (appt: Appointment) => void;
  onDeleteAppointment: (id: string) => void;
  onToggleStatus: (id: string, newStatus: AppointmentStatus) => void;
  onOpenNewAppointment: (dateStr?: string) => void;
  onSelectDate?: (dateStr: string) => void;
  filterTitle?: string;
  viewScope?: 'day' | 'month' | 'all';
  onViewScopeChange?: (scope: 'day' | 'month' | 'all') => void;
}

export const AgendaList: React.FC<AgendaListProps> = ({
  selectedDateStr,
  appointments,
  allAppointments = [],
  allAppointmentsCount,
  onEditAppointment,
  onDeleteAppointment,
  onToggleStatus,
  onOpenNewAppointment,
  onSelectDate,
  filterTitle,
  viewScope = 'day',
  onViewScopeChange
}) => {
  const normalizedSelected = normalizeDateStr(selectedDateStr);
  const formattedDateHeader = formatFullDatePT(normalizedSelected);

  // Group all appointments by date to show days with events when current day is empty
  const otherDaysWithAppointments = React.useMemo(() => {
    const map: Record<string, Appointment[]> = {};
    allAppointments.forEach((appt) => {
      const d = normalizeDateStr(appt.date);
      if (d !== normalizedSelected) {
        if (!map[d]) map[d] = [];
        map[d].push(appt);
      }
    });
    return Object.entries(map).sort(([a], [b]) => a.localeCompare(b));
  }, [allAppointments, normalizedSelected]);

  return (
    <div
      id="agenda-list-section"
      className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-6 shadow-sm space-y-4 scroll-mt-6 flex flex-col"
    >
      
      {/* Header section with Scope Tabs and Quick Add */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <CalendarIcon className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              <span>
                {filterTitle
                  ? filterTitle
                  : viewScope === 'day'
                  ? `Agenda para ${formattedDateHeader}`
                  : viewScope === 'month'
                  ? 'Compromissos do Mês'
                  : 'Todos os Compromissos'}
              </span>
            </h3>

            {/* Scope pill switches */}
            {onViewScopeChange && (
              <div className="inline-flex bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg text-xs font-semibold">
                <button
                  onClick={() => onViewScopeChange('day')}
                  className={`px-2.5 py-1 rounded-md transition ${
                    viewScope === 'day'
                      ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  Dia Selecionado
                </button>
                <button
                  onClick={() => onViewScopeChange('month')}
                  className={`px-2.5 py-1 rounded-md transition ${
                    viewScope === 'month'
                      ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  Mês Todo
                </button>
                <button
                  onClick={() => onViewScopeChange('all')}
                  className={`px-2.5 py-1 rounded-md transition ${
                    viewScope === 'all'
                      ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  Geral ({allAppointmentsCount})
                </button>
              </div>
            )}
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {appointments.length}{' '}
            {appointments.length === 1 ? 'compromisso listado' : 'compromissos listados'}
            {viewScope === 'day' && allAppointmentsCount > appointments.length && (
              <span> • Total na agenda: {allAppointmentsCount}</span>
            )}
          </p>
        </div>

        <button
          onClick={() => onOpenNewAppointment(normalizedSelected)}
          className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition shadow-sm"
        >
          <Plus className="w-4 h-4" />
          <span>Adicionar no dia</span>
        </button>
      </div>

      {/* Agenda Items List */}
      {appointments.length === 0 ? (
        <div className="py-8 sm:py-10 text-center space-y-4 bg-slate-50/50 dark:bg-slate-800/30 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 p-6">
          <div className="w-12 h-12 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 rounded-2xl flex items-center justify-center mx-auto">
            <CalendarDays className="w-6 h-6" />
          </div>
          <div className="max-w-md mx-auto">
            <h4 className="text-sm font-semibold text-slate-800 dark:text-slate-200">
              Nenhum compromisso marcado para {viewScope === 'day' ? formattedDateHeader : 'este filtro'}
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              {viewScope === 'day'
                ? 'Clique no botão abaixo para adicionar um compromisso ou anotação nesta data.'
                : 'Nenhum item corresponde aos filtros selecionados.'}
            </p>
          </div>

          <div className="flex items-center justify-center gap-2 flex-wrap">
            <button
              onClick={() => onOpenNewAppointment(normalizedSelected)}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-sm transition"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar Neste Dia</span>
            </button>

            {onViewScopeChange && allAppointmentsCount > 0 && viewScope === 'day' && (
              <button
                onClick={() => onViewScopeChange('month')}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold transition"
              >
                <CalendarIcon className="w-4 h-4 text-indigo-500" />
                <span>Ver Todos os {allAppointmentsCount} Compromissos</span>
              </button>
            )}
          </div>

          {/* Quick jump suggestions to days with appointments */}
          {viewScope === 'day' && otherDaysWithAppointments.length > 0 && onSelectDate && (
            <div className="pt-4 mt-2 border-t border-slate-200/60 dark:border-slate-800 text-left">
              <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>Você tem anotações cadastradas em outros dias:</span>
              </p>
              <div className="flex flex-wrap gap-2">
                {otherDaysWithAppointments.slice(0, 6).map(([dateStr, items]) => {
                  const summary = getDayStatusSummary(items);
                  const style = summary.primaryStatus ? getRowColorClasses(summary.primaryStatus) : null;

                  return (
                    <button
                      key={dateStr}
                      onClick={() => onSelectDate(dateStr)}
                      className="px-3 py-1.5 bg-white dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 text-slate-700 dark:text-slate-200 hover:text-indigo-600 dark:hover:text-indigo-300 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium flex items-center gap-1.5 transition shadow-2xs group"
                    >
                      <CalendarIcon className="w-3.5 h-3.5 text-indigo-500 group-hover:scale-110 transition" />
                      <span>{formatShortDatePT(dateStr)}</span>
                      
                      {/* Synchronized status dots for the day */}
                      <div className="flex items-center gap-0.5">
                        {summary.statuses.map((st) => (
                          <span
                            key={st}
                            className={`w-1.5 h-1.5 rounded-full ${
                              st === 'cancelled'
                                ? 'bg-rose-500'
                                : st === 'completed'
                                ? 'bg-emerald-500'
                                : st === 'in_progress'
                                ? 'bg-amber-500'
                                : 'bg-purple-500'
                            }`}
                          />
                        ))}
                      </div>

                      {style && (
                        <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full border ${style.chipBg}`}>
                          {items.length}
                        </span>
                      )}
                      <ChevronRight className="w-3 h-3 text-slate-400 group-hover:text-indigo-500 transition" />
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          {appointments.map((appt) => {
            const effectiveStatus = getEffectiveStatus(appt);
            const hasNotes = Boolean(appt.notes && appt.notes.trim().length > 0);
            const rowStyle = getRowColorClasses(effectiveStatus, hasNotes);
            const apptDateFormatted = formatShortDatePT(appt.date);

            return (
              <div
                key={appt.id}
                className={`group relative rounded-xl p-4 border transition-all shadow-2xs ${rowStyle.bg} ${rowStyle.border}`}
              >
                <div className="flex items-start justify-between gap-3">
                  
                  {/* Left: Quick Status Actions + Content Details */}
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    
                    {/* Status Direct Selector / Toggle */}
                    <div className="mt-0.5 shrink-0 flex flex-col items-center gap-1">
                      <button
                        type="button"
                        onClick={() =>
                          onToggleStatus(
                            appt.id,
                            effectiveStatus === 'completed' ? 'pending' : 'completed'
                          )
                        }
                        title={
                          effectiveStatus === 'completed'
                            ? 'Clique para reabrir como Pendente'
                            : 'Clique para marcar como Concluído (Verde)'
                        }
                        className="transition hover:scale-110"
                      >
                        {effectiveStatus === 'completed' ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 fill-emerald-100 dark:fill-emerald-950" />
                        ) : effectiveStatus === 'cancelled' ? (
                          <XCircle className="w-5 h-5 text-rose-600 dark:text-rose-400" />
                        ) : effectiveStatus === 'in_progress' ? (
                          <AlertCircle className="w-5 h-5 text-amber-600 dark:text-amber-400 fill-amber-100 dark:fill-amber-950" />
                        ) : (
                          <Circle className="w-5 h-5 text-purple-600 dark:text-purple-400 hover:text-purple-700" />
                        )}
                      </button>
                    </div>

                    {/* Content Details */}
                    <div className="flex-1 min-w-0 space-y-1.5">
                      
                      {/* Top Badges: Date, Time, Category, Status Quick Selector, Notes Alert */}
                      <div className="flex items-center gap-2 flex-wrap">
                        {/* Synchronized Date chip */}
                        {viewScope !== 'day' && (
                          <button
                            onClick={() => onSelectDate && onSelectDate(appt.date)}
                            className={`inline-flex items-center gap-1 text-xs font-bold px-2 py-0.5 rounded-md border transition ${rowStyle.chipBg}`}
                          >
                            <CalendarIcon className="w-3 h-3 text-current opacity-80" />
                            {apptDateFormatted}
                          </button>
                        )}

                        {/* Scheduled Time */}
                        {appt.time && (
                          <span className="inline-flex items-center gap-1 text-xs font-semibold text-slate-700 dark:text-slate-300 bg-white/80 dark:bg-slate-800/80 px-2 py-0.5 rounded-md border border-slate-200/60 dark:border-slate-700">
                            <Clock className="w-3 h-3 text-indigo-500" />
                            {appt.time}
                          </span>
                        )}

                        {/* Category */}
                        <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md border ${getCategoryBadgeStyle(appt.category)}`}>
                          {getCategoryLabel(appt.category)}
                        </span>

                        {/* Interactive Status Selector Dropdown */}
                        <div className="relative inline-flex items-center">
                          <select
                            value={effectiveStatus}
                            onChange={(e) =>
                              onToggleStatus(appt.id, e.target.value as AppointmentStatus)
                            }
                            title="Alterar status do compromisso"
                            className={`text-[11px] font-bold px-2 py-0.5 rounded-md cursor-pointer focus:outline-none transition ${rowStyle.badge}`}
                          >
                            <option value="pending">🟣 Pendente (Roxo)</option>
                            <option value="in_progress">🟡 Em Andamento (Amarelo)</option>
                            <option value="completed">🟢 Concluído (Verde)</option>
                            <option value="cancelled">🔴 Cancelado (Vermelho)</option>
                          </select>
                        </div>

                        {/* Note Badge Indicator */}
                        {hasNotes && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-medium text-amber-800 dark:text-amber-300 bg-amber-100/90 dark:bg-amber-950/80 px-2 py-0.5 rounded-md border border-amber-300/80 dark:border-amber-800">
                            <FileText className="w-3 h-3 text-amber-600 dark:text-amber-400" />
                            Anotação
                          </span>
                        )}
                      </div>

                      {/* Title */}
                      <h4 className={`text-sm font-semibold leading-snug break-words ${rowStyle.text}`}>
                        {appt.title}
                      </h4>

                      {/* Inline Notes Preview */}
                      {hasNotes && (
                        <div className="mt-2 text-xs text-slate-700 dark:text-slate-300 bg-amber-50/60 dark:bg-slate-800/80 border border-amber-200/80 dark:border-amber-900/50 rounded-xl p-3 space-y-1">
                          <div className="flex items-center gap-1.5 text-amber-800 dark:text-amber-400 font-bold text-[11px] uppercase tracking-wide">
                            <FileText className="w-3.5 h-3.5" />
                            <span>Anotação:</span>
                          </div>
                          <p className="whitespace-pre-wrap leading-relaxed">
                            {appt.notes}
                          </p>
                        </div>
                      )}

                    </div>
                  </div>

                  {/* Right Actions: Google Calendar Export, Edit, Delete */}
                  <div className="flex items-center gap-1 shrink-0 opacity-90 group-hover:opacity-100">
                    <a
                      href={generateGoogleCalendarUrl(appt)}
                      target="_blank"
                      rel="noopener noreferrer"
                      title="Exportar este compromisso para Google Agenda"
                      className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-slate-800 rounded-lg transition flex items-center gap-1 text-xs font-medium"
                    >
                      <CalendarIcon className="w-4 h-4 text-indigo-500" />
                      <span className="hidden xl:inline text-[11px]">Google Agenda</span>
                      <ExternalLink className="w-3 h-3 text-slate-400" />
                    </a>

                    <button
                      onClick={() => onEditAppointment(appt)}
                      title="Editar compromisso / alterar dados"
                      className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-slate-800 rounded-lg transition flex items-center gap-1"
                    >
                      <Pencil className="w-4 h-4" />
                      <span className="hidden sm:inline text-[11px] font-medium">Editar</span>
                    </button>

                    <button
                      onClick={() => onDeleteAppointment(appt.id)}
                      title="Excluir compromisso"
                      className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-slate-800 rounded-lg transition flex items-center gap-1"
                    >
                      <Trash2 className="w-4 h-4" />
                      <span className="hidden sm:inline text-[11px] font-medium text-rose-600">Excluir</span>
                    </button>
                  </div>

                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Status Legend Bar */}
      <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
        <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
          Cores dos Status:
        </span>
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          {STATUS_LEGEND.map((item) => (
            <span
              key={item.status}
              className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md border text-[11px] font-medium ${item.badgeClass}`}
            >
              <span className={`w-2 h-2 rounded-full ${item.dotClass}`} />
              <span>{item.label}</span>
              <span className="opacity-70 text-[10px]">({item.color})</span>
            </span>
          ))}
        </div>
      </div>

    </div>
  );
};
