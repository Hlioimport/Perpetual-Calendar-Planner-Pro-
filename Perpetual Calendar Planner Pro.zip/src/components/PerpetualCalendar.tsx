import React from 'react';
import { WEEKDAYS_SHORT_PT, getCalendarMatrix, CalendarDayCell, normalizeDateStr } from '../lib/dateUtils';
import { Appointment } from '../types';
import {
  getEffectiveStatus,
  getRowColorClasses,
  getDayStatusSummary,
  STATUS_LEGEND
} from '../lib/colorUtils';
import { FileText, Plus } from 'lucide-react';

interface PerpetualCalendarProps {
  currentDate: Date;
  selectedDateStr: string;
  onSelectDate: (dateStr: string) => void;
  appointments: Appointment[];
  onOpenNewForDate: (dateStr: string) => void;
}

export const PerpetualCalendar: React.FC<PerpetualCalendarProps> = ({
  currentDate,
  selectedDateStr,
  onSelectDate,
  appointments,
  onOpenNewForDate
}) => {
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const daysMatrix: CalendarDayCell[] = getCalendarMatrix(year, month);
  const normalizedSelectedDate = normalizeDateStr(selectedDateStr);

  // Group appointments by normalized date
  const appointmentsByDate = React.useMemo(() => {
    const map: Record<string, Appointment[]> = {};
    appointments.forEach((appt) => {
      const normDate = normalizeDateStr(appt.date);
      if (!map[normDate]) {
        map[normDate] = [];
      }
      map[normDate].push(appt);
    });
    return map;
  }, [appointments]);

  const handleCellClick = (dateString: string) => {
    onSelectDate(dateString);
    // On smaller screens, smoothly scroll to Agenda List so user sees day details
    if (typeof window !== 'undefined' && window.innerWidth < 1024) {
      const el = document.getElementById('agenda-list-section');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden flex flex-col">
      
      {/* Weekday Labels Header */}
      <div className="grid grid-cols-7 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-center py-2.5">
        {WEEKDAYS_SHORT_PT.map((day, idx) => (
          <div
            key={day}
            className={`text-xs font-bold uppercase tracking-wider ${
              idx === 0 || idx === 6
                ? 'text-rose-500 dark:text-rose-400'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            {day}
          </div>
        ))}
      </div>

      {/* Perpetual Days Grid */}
      <div className="grid grid-cols-7 divide-x divide-y divide-slate-100 dark:divide-slate-800/60 bg-slate-100/40 dark:bg-slate-900/40">
        {daysMatrix.map((cell) => {
          const isSelected = cell.dateString === normalizedSelectedDate;
          const dayAppts = appointmentsByDate[cell.dateString] || [];
          const daySummary = getDayStatusSummary(dayAppts);
          const primaryStyle = daySummary.primaryStatus ? getRowColorClasses(daySummary.primaryStatus) : null;

          return (
            <div
              key={cell.dateString}
              onClick={() => handleCellClick(cell.dateString)}
              className={`group relative min-h-[100px] sm:min-h-[120px] p-1.5 sm:p-2 transition cursor-pointer flex flex-col justify-between ${
                !cell.isCurrentMonth
                  ? 'bg-slate-50/50 dark:bg-slate-950/40 text-slate-400 dark:text-slate-600'
                  : isSelected
                  ? 'bg-indigo-50/90 dark:bg-indigo-950/50 text-indigo-900 dark:text-indigo-200 ring-2 ring-indigo-500 ring-inset z-10 shadow-xs'
                  : cell.isToday
                  ? 'bg-amber-50/60 dark:bg-amber-950/20'
                  : 'bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800/40'
              }`}
            >
              {/* Top Accent Bar if day has appointments */}
              {daySummary.primaryStatus && (
                <div
                  className={`absolute top-0 left-0 right-0 h-1 ${
                    daySummary.primaryStatus === 'cancelled'
                      ? 'bg-rose-500'
                      : daySummary.primaryStatus === 'completed'
                      ? 'bg-emerald-500'
                      : daySummary.primaryStatus === 'in_progress'
                      ? 'bg-amber-500'
                      : 'bg-purple-500'
                  }`}
                />
              )}

              {/* Day Cell Header: Number + Status Dots + Count Badge + Quick Add */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span
                    className={`inline-flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold transition ${
                      isSelected
                        ? 'bg-indigo-600 text-white shadow-sm ring-2 ring-indigo-300 dark:ring-indigo-700'
                        : cell.isToday
                        ? 'bg-amber-500 text-white shadow-sm'
                        : cell.isWeekend
                        ? 'text-rose-600 dark:text-rose-400'
                        : cell.isCurrentMonth
                        ? 'text-slate-800 dark:text-slate-200'
                        : 'text-slate-400 dark:text-slate-600'
                    }`}
                  >
                    {cell.dayNumber}
                  </span>

                  {/* Synchronized Status Dots per Date */}
                  {daySummary.statuses.length > 0 && (
                    <div className="flex items-center gap-0.5" title="Status dos compromissos neste dia">
                      {daySummary.statuses.map((st) => (
                        <span
                          key={st}
                          className={`w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full shadow-2xs ${
                            st === 'cancelled'
                              ? 'bg-rose-500'
                              : st === 'completed'
                              ? 'bg-emerald-500'
                              : st === 'in_progress'
                              ? 'bg-amber-500'
                              : 'bg-purple-500'
                          }`}
                        />
                      ))}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-1">
                  {/* Note pulse badge indicator */}
                  {daySummary.hasNotes && (
                    <span
                      title="Contém anotações neste dia"
                      className="w-2 h-2 rounded-full bg-amber-500 animate-pulse shrink-0"
                    />
                  )}

                  {/* Synchronized Day Count Badge */}
                  {dayAppts.length > 0 && primaryStyle && (
                    <span
                      title={`${dayAppts.length} compromisso(s) - Status principal: ${primaryStyle.label}`}
                      className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full border ${primaryStyle.chipBg}`}
                    >
                      {dayAppts.length}
                    </span>
                  )}

                  {/* Hover Quick Add Plus button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenNewForDate(cell.dateString);
                    }}
                    title="Adicionar compromisso neste dia"
                    className="opacity-0 group-hover:opacity-100 p-0.5 text-indigo-600 hover:text-indigo-800 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-950 rounded transition"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Day Appointments List Preview with Synchronized Status Colors */}
              <div className="mt-1 space-y-1 overflow-hidden flex-1">
                {dayAppts.slice(0, 3).map((appt) => {
                  const effectiveStatus = getEffectiveStatus(appt);
                  const style = getRowColorClasses(effectiveStatus);
                  const hasNote = appt.notes && appt.notes.trim().length > 0;

                  return (
                    <div
                      key={appt.id}
                      title={`${appt.title} • ${style.label} (${style.colorName})`}
                      className={`text-[11px] leading-tight px-1.5 py-0.5 rounded border truncate flex items-center justify-between gap-1 transition font-medium shadow-2xs ${style.chipBg} ${
                        effectiveStatus === 'cancelled' ? 'line-through opacity-75' : ''
                      }`}
                    >
                      <div className="flex items-center gap-1 min-w-0 truncate">
                        <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${style.dot}`} />
                        <span className="truncate">
                          {appt.time ? `${appt.time} ` : ''}{appt.title}
                        </span>
                      </div>
                      {hasNote && <FileText className="w-2.5 h-2.5 shrink-0 opacity-80" />}
                    </div>
                  );
                })}

                {dayAppts.length > 3 && (
                  <div className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 pl-1">
                    +{dayAppts.length - 3} mais...
                  </div>
                )}
              </div>

            </div>
          );
        })}
      </div>

      {/* Status Legend Footer Synchronized with Calendar */}
      <div className="p-3 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
        <span className="text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider">
          Legenda de Cores Sincronizadas:
        </span>
        <div className="flex flex-wrap items-center gap-3">
          {STATUS_LEGEND.map((item) => (
            <div key={item.status} className="flex items-center gap-1.5 font-medium">
              <span className={`w-2.5 h-2.5 rounded-full ${item.dotClass} shadow-2xs`} />
              <span className="text-slate-700 dark:text-slate-300">
                {item.label} <span className="text-slate-400 dark:text-slate-500 text-[10px]">({item.color})</span>
              </span>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
